import os
import cv2
import torch
import math
import numpy as np
from skimage.feature import canny
from torch.utils.data import Dataset, DataLoader
from matplotlib import pyplot as plt
import torchvision.transforms as transforms


class ImgSyn_Dataset(Dataset):
    def __init__(self, num, img_file):
        self.num = num
        self.img_file = img_file
        self.img_list = sorted(os.listdir(self.img_file))

    def __getitem__(self, index):
        return self.load_item(index)

    def __len__(self):
        return self.num

    def load_item(self, index):
        Ig = cv2.imread(self.img_file + self.img_list[index])  # ((256,256,3))
        Ig = cv2.resize(Ig, (256, 256))
        Eg = self.load_edge(Ig)
        Ig = cv2.cvtColor(Ig, cv2.COLOR_BGR2RGB)
        Ig = Ig.astype('float') / 127.5 - 1.
        Ig = self.tensor(Ig)
        Eg = self.tensor(Eg)
        return {'Ig': Ig,
                'Eg': Eg}

    def load_edge(self, img):
        img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        edge = canny(img / 255.0, sigma=2, mask=None).astype(float)
        edge = edge.reshape((256, 256, 1))
        edge = edge * 2. - 1.
        return edge

    def tensor(self, img):
        return torch.from_numpy(img).float().permute(2, 0, 1)


if __name__ == '__main__':
    os.environ['CUDA_VISIBLE_DEVICES'] = '3'
    img_file = '/opt/data/zecheng/MyDataSet/Img_synthesis/train/Image/'
    num = 1
    dataloader = DataLoader(ImgSyn_Dataset(num, img_file), batch_size=1, shuffle=True, num_workers=4)

    for index, data in enumerate(dataloader):
        Ig, Eg = data['Ig'], data['Eg']
    print('Done')
