import os
import cv2
import torch
import argparse
import numpy as np
from ImgSyn_Dataset import ImgSyn_Dataset
from Model import ImgModel
from torch.utils.data import Dataset, DataLoader
from matplotlib import pyplot as plt
import torchvision.transforms as transforms


def nn_match_two_way(desc1, desc2, nn_thresh):
    """
    Performs two-way nearest neighbor matching of two sets of descriptors, such
    that the NN match from descriptor A->B must equal the NN match from B->A.

    Inputs:
      desc1 - NxM numpy matrix of N corresponding M-dimensional descriptors.
      desc2 - NxM numpy matrix of N corresponding M-dimensional descriptors.
      nn_thresh - Optional descriptor distance below which is a good match.

    Returns:
      matches - 3xL numpy array, of L matches, where L <= N and each column i is
                a match of two descriptors, d_i in image 1 and d_j' in image 2:
                [d_i index, d_j' index, match_score]^T
    """
    assert desc1.shape[0] == desc2.shape[0]
    if desc1.shape[1] == 0 or desc2.shape[1] == 0:
        return np.zeros((3, 0))
    if nn_thresh < 0.0:
        raise ValueError('\'nn_thresh\' should be non-negative')
    # Compute L2 distance. Easy since vectors are unit normalized.
    dmat = np.dot(desc1.T, desc2)
    dmat = np.sqrt(2 - 2 * np.clip(dmat, -1, 1))
    # Get NN indices and scores.
    idx = np.argmin(dmat, axis=1)
    scores = dmat[np.arange(dmat.shape[0]), idx]
    # Threshold the NN matches.
    keep = scores < nn_thresh
    # Check if nearest neighbor goes both directions and keep those.
    idx2 = np.argmin(dmat, axis=0)
    keep_bi = np.arange(len(idx)) == idx2[idx]
    keep = np.logical_and(keep, keep_bi)
    idx = idx[keep]
    scores = scores[keep]
    # Get the surviving point indices.
    m_idx1 = np.arange(desc1.shape[1])[keep]
    m_idx2 = idx
    # Populate the final 3xN match data structure.
    matches = np.zeros((3, int(keep.sum())))
    matches[0, :] = m_idx1
    matches[1, :] = m_idx2
    matches[2, :] = scores
    return matches


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--type', type=str, default='test', help='train or test the model', choices=['train', 'test'])
    parser.add_argument('--gpu_id', type=str, default='0')
    parser.add_argument('--device', type=str, default='cuda:0')
    # parser.add_argument('--img_file', type=str, default='/opt/data/zecheng/MyDataSet/Fid/celeba/Source/')
    parser.add_argument('--img_file', type=str, default='/opt/data/zecheng/MyDataSet/attack_test/test/')
    parser.add_argument('--img_file_test', type=str, default='/opt/data/zecheng/MyDataSet/Img_synthesis/test/Image/')
    parser.add_argument('--model_dir', type=str, default='/home/zecheng/Code/Image_synthesis/stage13/Demo18/weight/1/')
    parser.add_argument('--save_dir', type=str, default='/opt/data/zecheng/MyDataSet/Fid/Synthesis/')
    parser.add_argument('--log', type=str, default='/opt/data/zecheng/log/Image_synthesis/test/')
    parser.add_argument('--img_channel', type=int, default=257)
    parser.add_argument('--des_channel', type=int, default=256)
    parser.add_argument('--num', type=int, default=1)
    parser.add_argument('--n_epochs', type=int, default=1)
    parser.add_argument('--batch_size', type=int, default=1)
    parser.add_argument('--offset', type=int, default=1)

    opt = parser.parse_args()
    os.environ['CUDA_VISIBLE_DEVICES'] = opt.gpu_id

    model = ImgModel(opt)
    if os.path.exists('./weight/1/superpoint_v1.pth'):
        model.sp_net.load_state_dict(
            torch.load('./weight/1/superpoint_v1.pth', map_location='cpu'))
        print('Load SuperPoint Model')

    used_dataset = ImgSyn_Dataset(num=opt.num, img_file=opt.img_file)
    loader = DataLoader(dataset=used_dataset, batch_size=opt.batch_size, shuffle=False, num_workers=8)
    to_gray = transforms.Grayscale(1)
    for cnt, items in enumerate(loader):

        Ig, Eg = items['Ig'].cuda(), items['Eg'].cuda()
        Ig_show = ((Ig + 1.) / 2.).detach().cpu().squeeze().permute(1, 2, 0).numpy()
        # plt.imshow(Ig_show)
        # plt.show()
        Ig_gray = to_gray(Ig)
        Ig_gray = (Ig_gray + 1.) / 2.
        coarse_kp, coarse_des = model.sp_net(Ig_gray)
        Ig_kp, Ig_des = model.handle(coarse_kp.squeeze(0), coarse_des.squeeze(0))
        Ig_kp = [cv2.KeyPoint(int(round(p[0])), int(round(p[1])), 1) for p in Ig_kp.T]
        Ig_gray = (Ig_gray * 255.).squeeze(0).permute(1, 2, 0).cpu().numpy()
        img_plt = cv2.merge([Ig_gray, Ig_gray, Ig_gray]).astype('uint8')
        # for p in Ig_kp:
        #     cv2.circle(img_plt, (int(p[0]), int(p[1])), radius=3, color=(0, 255, 0))
        img_plt = cv2.drawKeypoints(img_plt, Ig_kp, img_plt, color=(0, 255, 0))
        # plt.imshow(img_plt)
        # plt.show()
        # cv2.imwrite('/home/zecheng/Sp_{}.jpg'.format(i), img_plt)
        i = 1
        for des in Ig_des.T:
            plt.title('des:{}'.format(i))
            plt.plot(des)
            plt.savefig('./images/tmp/des_%03d' % i)
            plt.show()
            i = i + 1
    print('Done')

    # torchvision.utils.save_image(Io_plt, './images/test/Io_{}.jpg'.format(cnt), normalize=False)
