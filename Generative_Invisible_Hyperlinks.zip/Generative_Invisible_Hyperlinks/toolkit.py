# -*- coding:utf8 -

import os
import torch
import torchvision
from torchvision import transforms
import logging
import math
import numpy as np
import numpy
import cv2


def save_images(original_images, watermarked_images, epoch, folder, resize_to=None):
    images = original_images[:original_images.shape[0], :, :, :].cpu()
    watermarked_images = watermarked_images[:watermarked_images.shape[0], :, :, :].cpu()

    # scale values to range [0, 1] from original range of [-1, 1]
    images = (images + 1) / 2
    watermarked_images = (watermarked_images + 1) / 2

    stacked_images = torch.cat([images, watermarked_images], dim=0)
    filename = os.path.join(folder, 'epoch-{}.png'.format(epoch + 1))
    torchvision.utils.save_image(stacked_images, filename, original_images.shape[0], normalize=False)


def save_image(images, epoch, folder, type, resize_to=None):
    image = images[:8, :, :, :].cpu()

    # scale values to range [0, 1] from original range of [-1, 1]
    image = (image + 1) / 2
    filename = os.path.join(folder, type + '_%03d.jpg' % epoch)
    torchvision.utils.save_image(image, filename, normalize=False)


def save_test_image(images, train_number, folder, type, resize_to=None):
    if images.shape[0] > 8:
        image = images[:8, :, :, :].cpu()
    else:
        image = images[:images.shape[0], :, :, :].cpu()

    # scale values to range [0, 1] from original range of [-1, 1]
    image = (image + 1) / 2
    filename = folder + type + '_%06d.jpg' % train_number
    torchvision.utils.save_image(image, filename, normalize=False)


def data_loader(data_dir, batch_size, num_workers):
    augs = transforms.Compose([
        transforms.CenterCrop((256, 256)),
        transforms.ToTensor(),
        transforms.Normalize([0.5, 0.5, 0.5], [0.5, 0.5, 0.5])
    ])

    train_images = torchvision.datasets.ImageFolder(data_dir, transform=augs)
    train_loader = torch.utils.data.DataLoader(train_images, batch_size=batch_size, shuffle=True,
                                               num_workers=num_workers)

    return train_loader


def psnr(img1, img2):
    mse = numpy.mean((img1 - img2) ** 2)
    if mse == 0:
        return 100
    PIXEL_MAX = 1
    return 20 * math.log10(PIXEL_MAX / math.sqrt(mse))
